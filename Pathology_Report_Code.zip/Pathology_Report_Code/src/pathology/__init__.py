"""Matched pathology image analysis."""
